# Internship Dashboard

Shortcuts:
- Department
- Mentor
- Intern
- Task
