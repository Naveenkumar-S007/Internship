# DocTypes

## Department
- Department Name
- Description

## Mentor
- Mentor Name
- Email
- Department

## Intern
- Intern Name
- Email
- College
- Mentor
- Status

## Task
- Task Title
- Intern
- Due Date
- Status
