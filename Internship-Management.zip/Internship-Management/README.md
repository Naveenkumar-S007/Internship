# Internship Management System

A simple Frappe Framework v15 demo application created for learning ERPNext customization.

## Features
- Department Management
- Mentor Management
- Intern Management
- Task Assignment
- Workspace Dashboard
- Reports
